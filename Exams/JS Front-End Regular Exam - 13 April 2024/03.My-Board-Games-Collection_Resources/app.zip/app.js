let host = 'http://localhost:3030/jsonstore/games/';

// Form input fiels
let nameInput = document.getElementById('g-name');
let typeInput = document.getElementById('type');
let playersInput = document.getElementById('players');


// Buttons
let loadBtn = document.getElementById('load-games');
let addBtn = document.getElementById('add-game');
let editBtn = document.getElementById('edit-game');


// Ebent listeners
loadBtn.addEventListener('click', onLoad);
addBtn.addEventListener('click', async (ev) => {
    ev.preventDefault();
    onAdd();
});

editBtn.addEventListener('click', async (ev) => {
    ev.preventDefault();
    onEdit();
});


// DOM Manipulation
async function onLoad() {
    let games = await loadGames();

    let list = document.getElementById('games-list');
    list.innerHTML = '';

    for (let game of games) {
        let divBoardGames = document.createElement('div');
        divBoardGames.className = 'board-game';

        let divContent = document.createElement('div');
        divContent.className = 'content';

        let pName = document.createElement('p');
        pName.textContent = game.name;

        let pType = document.createElement('p');
        pType.textContent = game.type;

        let pPlaers = document.createElement('p');
        pPlaers.textContent = game.players;

        let divBtnContainer = document.createElement('div');

        let changeBtn = document.createElement('button');
        changeBtn.className = 'change-btn';
        changeBtn.textContent = 'Change';
        changeBtn.addEventListener('click', () => onRecordEdit(game));

        let delBtn = document.createElement('button');
        delBtn.className = 'delete-btn';
        delBtn.textContent = 'Delete';
        delBtn.addEventListener('click', async (ev) => {
            ev.preventDefault();
            deleteGame(game._id);
            onLoad();
       });

        // Append buttons to DIV
        divBtnContainer.appendChild(changeBtn);
        divBtnContainer.appendChild(delBtn);

        // Append p ele to div
        divContent.appendChild(pName);
        divContent.appendChild(pType);
        divContent.appendChild(pPlaers);

        divBoardGames.appendChild(divContent);
        divBoardGames.appendChild(divBtnContainer);

        list.appendChild(divBoardGames);

    }
    
}


async function onAdd() {
    let name = nameInput.value;
    let type = typeInput.value;
    let players = playersInput.value;

    if(!name || !type || !players) {
        return;
    }

    await addGame(name, type, players);

    nameInput.value = '';
    typeInput.value = '';
    playersInput.value = '';

    onLoad();
}


function onRecordEdit(game) {
    nameInput.value = game.name;
    typeInput.value = game.type;
    playersInput.value = game.players;

    editBtn.dataset.id = game._id;

    addBtn.disabled = true;
    editBtn.disabled = false;
}


async function onEdit() {
    let name = nameInput.value;
    let type = typeInput.value;
    let players = playersInput.value;
    let id = editBtn.dataset.id;

    if(!name || !type || !players) {
        return;
    }

    await updateGame(name, type, players, id);

    nameInput.value = '';
    typeInput.value = '';
    playersInput.value = '';

    addBtn.disabled = false;
    editBtn.disabled = true;
    editBtn.dataset.id = '';

    onLoad();
}


// API Manipulation

async function loadGames() {
    let res = await fetch(host);
    let data = await res.json();

    return Object.values(data);
}


async function addGame(name, type, players) {
    let record = {
        name,
        type,
        players
    }

    let options = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record)
    }

    await fetch(host, options);
}


async function updateGame(name, type, players, _id) {
    let record = {
        name,
        type,
        players,
        _id
    }

    let options = {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record)
    }
    
    await fetch(host + _id, options);
}


async function deleteGame(id) {
    let options = {
        method: 'DELETE'
    }
    
    await fetch(host + id, options);   
}