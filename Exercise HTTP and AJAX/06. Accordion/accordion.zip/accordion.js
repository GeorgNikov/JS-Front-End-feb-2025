window.addEventListener('load', onLoad)

// function solution() {

// }

async function onLoad() {
    let articles = await getArticles();
    let sectionMain = document.getElementById('main');

    for (let article of articles) {
        let divAccordion = document.createElement('div');
        divAccordion.className = 'accordion';

        let divHead = document.createElement('div');
        divHead.className = 'head';

        let span = document.createElement('span');
        span.textContent = article.title;

        let button = document.createElement('button');

        button.className = 'button';
        button.textContent = 'More';
        button.setAttribute('id', article._id);

        const extraContentDiv = document.createElement('div');
        extraContentDiv.className = 'extra';
        extraContentDiv.style.display = 'none';

        // Добавяме клик евент
        button.addEventListener('click', async () => {
            if (extraContentDiv.style.display === 'none') {
                // Зареждаме контента само веднъж
                if (extraContentDiv.innerHTML.trim() === '') {
                    const fullArticle = await getArticleContent(article._id);
                    const p = document.createElement('p');
                    p.textContent = fullArticle.content;
                    extraContentDiv.appendChild(p);
                }

                extraContentDiv.style.display = 'block';
                button.textContent = 'Less';
            } else {
                extraContentDiv.style.display = 'none';
                button.textContent = 'More';
            }
        });


        divHead.appendChild(span)
        divHead.appendChild(button);
        divAccordion.appendChild(divHead)
        divAccordion.appendChild(extraContentDiv);
        sectionMain.appendChild(divAccordion)
    }
}


async function getArticleContent(id) {
    const res = await fetch(`http://localhost:3030/jsonstore/advanced/articles/details/${id}`);
    const data = await res.json();

    return data;
}


async function getArticles() {
    let url = 'http://localhost:3030/jsonstore/advanced/articles/list/';

    let res = await fetch(url);
    let data = await res.json();

    return Object.values(data);
}